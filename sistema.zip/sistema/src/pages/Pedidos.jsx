4// import
import { useEffect } from "react";
import { useState } from "react";
import { ApiWebURL } from "../utils";
import dayjs from "dayjs";
import PageHeader from "../components/PageHeader";
import { useNavigate } from 'react-router-dom';

// function
function Pedidos() {
    
    const history = useNavigate();
    const [listaPedidos, setListaPedidos] = useState([]);
    const [listaPedidosFiltrados, setListaPedidosFiltrados] = useState([]);
    const [textoBuscar, setTextoBuscar] = useState([])
    const [columnaAnterior, setColumnaAnterior] = useState("")
    const [estadoAscendente, setEstadoAscendente] = useState(1)

    useEffect(() => {
        leerServicio()
    }, [])
///<Link to={"/pedidosdetalle/" + item.idpedido}>
    const leerServicio = () => {
        const rutaServicio = ApiWebURL + "pedidos.php";
        fetch(rutaServicio)
            .then(response => response.json())
            .then(data => {
                console.log(data)
                setListaPedidos(data)
                setListaPedidosFiltrados(data)
            })
    }

    const seleccionarColumna = (columna) => {
        let ascendente = estadoAscendente;
        
        if(columna !== columnaAnterior) {
            ascendente = 1
        } else {
            ascendente = -ascendente
        }

        setEstadoAscendente(ascendente)
        console.log(columna)
        const resultado = [...listaPedidosFiltrados].sort((a,b) => 
            a[columna]>b[columna] ? ascendente : -ascendente)
        setListaPedidosFiltrados(resultado)    
        setColumnaAnterior(columna)
    }

    const buscarTexto = (event) => {
        let texto = event.target.value
        setTextoBuscar(texto)
        console.log(texto)
        const resultado = listaPedidos.filter(item =>
            item["idpedido"].toUpperCase().includes(texto.toUpperCase()) ||
            item["fechapedido"].toUpperCase().includes(texto.toUpperCase()) ||
            item["nombres"].toUpperCase().includes(texto.toUpperCase()) ||
            item["usuario"].toUpperCase().includes(texto.toUpperCase()) ||
            item["total"].toUpperCase().includes(texto.toUpperCase())
        )
        setListaPedidosFiltrados(resultado)
    }

    const redirectPedidosDetalle = (data) => {
        history("/pedidosdetalle/" + data);
    }

    const dibujarTabla = () => {
        let c = 1;
        return (
            <table className="table">
                <thead>
                    <tr>
                        <th className="text-center">#</th>
                        <th className="text-center" onClick={() => seleccionarColumna("idpedido")}>Código Pedido</th>
                        <th className="text-center" onClick={() => seleccionarColumna("fechapedido")}>Fecha de Pedido</th>
                        <th className="text-center" onClick={() => seleccionarColumna("nombres")}>Nombre</th>
                        <th className="text-center" onClick={() => seleccionarColumna("usuario")}>Usuario</th>
                        <th className="text-center" onClick={() => seleccionarColumna("total")}>Total</th>
                    </tr>
                </thead>
                <tbody>
                    {listaPedidosFiltrados.map(item =>
                        <tr key={item.idpedido} onClick={() => redirectPedidosDetalle(item.idpedido)}>
                            <td className="text-end">{c++}</td>
                            <td className="text-end">{item.idpedido}</td>
                            <td className="text-center">{dayjs(item.fechapedido).format("MM/DD/YYYY")}</td>
                            <td>{item.nombres}</td>
                            <td>{item.usuario}</td>
                            <td className="text-end">S/. {item.total}</td>
                        </tr>
                    )}
                </tbody>
            </table>
        )
    }

   

    return (
        <>
            <PageHeader titulo="Pedidos" />
            <section id="pedidos" className='padded'>
                <div className="container">
                    <div className="mb-3">
                        <input type="text" className="form-control" placeholder="Indique expresión a buscar"
                            value={textoBuscar} onChange={(event) => buscarTexto(event)} />
                    </div>
                    {dibujarTabla()}
                </div>
            </section>
        </>
    )
}

export default Pedidos;