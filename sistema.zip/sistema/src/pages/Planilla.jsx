import { useEffect } from "react";
import { useState } from "react";
import PageHeader from "../components/PageHeader";
import dayjs from "dayjs";
import { ApiWebURL } from "../utils";
import { useNavigate } from 'react-router-dom'

function Planilla() {

    let c = 1;
    const history = useNavigate();
    const [listaItems, setListaItems] = useState([])
    const [total, setTotal] = useState(0)

    console.log(listaItems);

    useEffect(() => {
        leerDatosPlanilla()
    }, [])

    const leerDatosPlanilla = () => {
        let datosPlanilla = JSON.parse(sessionStorage.getItem("planilla"))
        
        setListaItems(datosPlanilla)
        if (datosPlanilla !== null) {
            calcularTotal(datosPlanilla)
        }
    }

    const calcularTotal = (datosPlanilla) => {
        console.log("DATA TOTAL " + datosPlanilla);
        let sumaTotal = datosPlanilla.reduce((acumulador, fila) => acumulador + 1, 0)
        setTotal(sumaTotal)
    }

    const dibujarTabla = () => {
        return (
            <table className="table">
                <thead>
                    <tr>
                        <th className="text-center">#</th>
                        <th className="text-center">Fecha Inicio</th>
                        <th className="text-center">Nombres y Apellidos</th>
                        <th className="text-center">Cargo</th>
                        <th className="text-center">Pais</th>
                        <th className="text-center">Teléfono</th>
                        <th className="text-center">Fotocheck</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    {listaItems !== null
                        ? listaItems.map(item =>
                            <tr key={item.nombres}>
                                <td className="text-end">{c++}</td>
                                <td className="text-center">{dayjs(item.fechacontratacion).format("MM/DD/YYYY")}</td>
                                <td>{item.nombres} {item.apellidos}</td>
                                <td>{item.cargo}</td>
                                <td>{item.pais} ({item.ciudad})</td>
                                <td className="text-end">{item.telefono}</td>
                                <td className="text-center">
                                    <img src={ApiWebURL + "fotos/" + item.foto} className="bandera" />
                                </td>
                                <td>
                                    <i className="bi bi-x-lg eliminar-item" title="Eliminar item" onClick={() => eliminarItem(item)}></i>
                                </td>
                            </tr>
                        )
                        : <></>
                    }
                </tbody>
            </table>
        )
    }

    const eliminarItem = (item) => {
        let carritoMenos = listaItems.filter(itemCart => itemCart.idempleado !== item.idempleado) 
        setListaItems(carritoMenos)
        sessionStorage.setItem("planilla", JSON.stringify(carritoMenos))
        calcularTotal(carritoMenos)
    }

    const vaciarPlanilla = () => {
        setListaItems([])
        sessionStorage.removeItem("planilla")
        setTotal(0)
    }

    const redirectPedidosDetalle = () => {
        history("/empleados");
    }

    return (
        <>
            <PageHeader titulo="Lista de Planilla" />
            <section id="planilla" className='padded'>
                <div className="container">

                    <button type="button" className="btn btn-secondary mb-4" onClick={() => redirectPedidosDetalle()}>
                        <i className="bi bi-caret-left-fill"></i> Volver a Empleados
                    </button>

                    <div className="row">
                        <div className="col-10">
                            {dibujarTabla()}
                            <button className="btn btn-danger" onClick={() => vaciarPlanilla()}>Vaciar planilla</button>
                        </div>
                        <div className="col-2">
                            <div className="card border-primary mb-3">
                                <div className="card-header">Total en Planilla</div>
                                <div className="card-body text-primary">
                                    <table className="table">
                                        <tbody>
                                            <tr>
                                                <th>Cantidad:</th><td className="text-end">{total}</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>


                </div>
            </section>
        </>
    )

}

export default Planilla