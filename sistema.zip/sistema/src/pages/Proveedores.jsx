import { useEffect } from "react";
import { useState } from "react";
import { ApiWebURL } from "../utils";
import PageHeader from "../components/PageHeader";

function Proveedores() {
    
    const [listaProveedores, setListaProveedores] = useState([])
    const [listaProveedoresFiltrados, setListaProveedoresFiltrados] = useState([])
    const [proveedorSeleccionado, setProveedorSeleccionado] = useState([])
    const [textoBuscar, setTextoBuscar] = useState([])
    const [columnaAnterior, setColumnaAnterior] = useState("")
    const [estadoAscendente, setEstadoAscendente] = useState(1)

    useEffect(() => {
        leerServicio()
    }, [])

    const leerServicio = () => {
        const rutaServicio = ApiWebURL + "proveedores.php";
        fetch(rutaServicio)
            .then(response => response.json())
            .then(data => {
                console.log(data)
                setListaProveedores(data)
                setListaProveedoresFiltrados(data)
            })
    }
    /*
        function dibujarTabla(){
        }
    */
    const modalProveedor = () => {
        return(
            <div className="modal fade" id="vistaRapidaModal" tabIndex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div className="modal-dialog modal-dialog-centered modal-lg">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h3 className="modal-title fs-5" id="exampleModalLabel">Proveedor</h3>
                            <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div className="modal-body">
                            <div className="row">
                                <div className="col"></div>
                                <div className="col">
                                    <table className="table">
                                        <tbody>
                                            <tr>
                                                <th>Código</th>
                                                <td className="text-end">{proveedorSeleccionado.idproveedor}</td>
                                            </tr>
                                            <tr>
                                                <th>Empresa</th>
                                                <td>{proveedorSeleccionado.nombreempresa}</td>
                                            </tr>
                                            <tr>
                                                <th>Contacto</th>
                                                <td>{proveedorSeleccionado.nombrecontacto}</td>
                                            </tr>
                                            <tr>
                                                <th>Cargo</th>
                                                <td>{proveedorSeleccionado.cargocontacto}</td>
                                            </tr>
                                            <tr>
                                                <th>País</th>
                                                <td>{proveedorSeleccionado.pais}</td>
                                            </tr>
                                            <tr>
                                                <th>Ciudad</th>
                                                <td>{proveedorSeleccionado.ciudad}</td>
                                            </tr>
                                            <tr>
                                                <th>Código postal</th>
                                                <td>{proveedorSeleccionado.codigopostal}</td>
                                            </tr>
                                            <tr>
                                                <th>Telefono</th>
                                                <td className="text-end">{proveedorSeleccionado.telefono}</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div className="modal-footer">
                            <button type="button" className="btn btn-primary" data-bs-dismiss="modal">Cerrar</button>
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    const leerProveedorSeleccionado = (item) => {
        setProveedorSeleccionado(item);
    }

    const dibujarTabla = () => {
        return (
            <>
                <table className="table">
                    <thead>
                        <tr>
                            <th onClick={() => seleccionarColumna("idproveedor")}>Código</th>
                            <th onClick={() => seleccionarColumna("nombreempresa")}>Empresa</th>
                            <th onClick={() => seleccionarColumna("nombrecontacto")}>Contacto</th>
                            <th onClick={() => seleccionarColumna("cargocontacto")}>Cargo</th>
                            <th onClick={() => seleccionarColumna("pais")}>País</th>
                            <th onClick={() => seleccionarColumna("ciudad")}>Ciudad</th>
                            <th>Acción</th>
                        </tr>
                    </thead>
                    <tbody>
                        {listaProveedoresFiltrados.map(item =>
                            <tr key={item.idproveedor}>
                                <td>{item.idproveedor}</td>
                                <td>{item.nombreempresa}</td>
                                <td>{item.nombrecontacto}</td>
                                <td>{item.cargocontacto}</td>
                                <td>{item.pais}</td>
                                <td>{item.ciudad}</td>
                                <td className="text-center">
                                    <i className="bi bi-eye-fill" data-bs-toggle="modal" 
                                        onClick={() => leerProveedorSeleccionado(item)}
                                        data-bs-target="#vistaRapidaModal">
                                    </i>
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>

                {modalProveedor()}
            
            </>
        )
    }

    const seleccionarColumna = (columna) => {
        let ascendente = estadoAscendente
        if(columna !== columnaAnterior){
            ascendente = 1
        }
        else{
            ascendente = -ascendente
        }
        setEstadoAscendente(ascendente)
        console.log(columna)
        const resultado = [...listaProveedoresFiltrados].sort((a,b) => 
            a[columna]>b[columna] ? ascendente : -ascendente)
        setListaProveedoresFiltrados(resultado)    
        setColumnaAnterior(columna)
    }

    const buscarTexto = (event) => {
        let texto = event.target.value
        setTextoBuscar(texto)
        console.log(texto)
        const resultado = listaProveedores.filter(item =>
            item["nombreempresa"].toUpperCase().includes(texto.toUpperCase()) ||
            item["nombrecontacto"].toUpperCase().includes(texto.toUpperCase()) ||
            item["cargocontacto"].toUpperCase().includes(texto.toUpperCase()) ||
            item["pais"].toUpperCase().includes(texto.toUpperCase()) ||
            item["ciudad"].toUpperCase().includes(texto.toUpperCase())
        )
        setListaProveedoresFiltrados(resultado)
    }

    return (
        <>
            <PageHeader titulo="Proveedores" />
            <section id="proveedores" className='padded'>
                <div className="container">
                    <div className="mb-3">
                        <input type="text" className="form-control" placeholder="Indique expresión a buscar"
                            value={textoBuscar} onChange={(event) => buscarTexto(event)} />
                    </div>
                    {dibujarTabla()}
                </div>
            </section>

            
        </>
    )
}

export default Proveedores