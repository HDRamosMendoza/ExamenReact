function Pagina404() {
    return (
        <section className="padded">
            <div className="container">
                <p className="display-1">404</p>
                <p>Página no encontrada</p>
            </div>
        </section>
    )
}

export default Pagina404