import { useEffect } from "react";
import { useState } from "react";
import { ApiWebURL, agregarPlanilla } from "../utils";
import PageHeader from "../components/PageHeader";
function Empleados() {
    const [listaEmpleados, setListaEmpleados] = useState([])
    const [cantidadPlanilla, setCantidadPlanilla] = useState(1)

    useEffect(() => {
        leerServicio()
    }, [])

    const leerServicio = () => {
        const rutaServicio = ApiWebURL + "empleados.php";
        fetch(rutaServicio)
            .then(response => response.json())
            .then(data => {
                console.log(data)
                setListaEmpleados(data)
            })
    }

    const dibujarCuadricula = () => {
        return (
            <div className="row row-cols-xxl-5 row-cols-xl-4 row-cols-lg-3 row-cols-md-2 row-cols-1 g-4">
            {listaEmpleados.map(item =>
                <div className="col" key={item.idempleado}>
                    <div className="card h-100">
                        <img src={ApiWebURL + "fotos/" + item.foto} className="card-img-top" alt="..."/>
                            <div className="card-body">
                                <h5 className="card-title">{item.nombres} {item.apellidos}</h5>
                                <p className="card-text">{item.cargo}</p>
                                <p className="card-text">
                                <button type="button" className="btn btn-secondary" 
                                    onClick = {() => agregarPlanilla(item, 1)}>
                                    <i  className="bi bi-list" title="Añadir a planilla">
                                    </i> Agregar a planilla
                                </button>
                                </p>
                            </div>
                    </div>
                </div>
            )}
            </div>
        )
    }

    return (
        <>
        <PageHeader titulo="Empleados" />
        <section id="empleados" className='padded'>
            <div className="container">
                {dibujarCuadricula()}
            </div>
        </section>
        </>
    )
}

export default Empleados