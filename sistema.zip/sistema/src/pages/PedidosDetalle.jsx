import { useEffect, useState } from "react"
import { useParams } from "react-router-dom"
import { ApiWebURL, agregarCarrito } from "../utils"
import PageHeader from "../components/PageHeader" 
import { useNavigate } from 'react-router-dom'

function PedidosDetalle() {
    
    let c = 1;
    const history = useNavigate();
    const [pedidoSeleccionado, setPedidoSeleccionado] = useState([])
    const [cantidadPedido, setCantidadPedido] = useState(1)

    useEffect(() => {
        leerServicio()
    }, [])

    let params = useParams()
    console.log(params)

    const leerServicio = () => {
        const rutaServicio = ApiWebURL + "pedidosdetalle.php?idpedido=" + params.idpedido;
        fetch(rutaServicio)
            .then(response => response.json())
            .then(data => {
                console.log(data)
                setPedidoSeleccionado(data)
            })
    }

    const redirectPedidosDetalle = () => {
        history("/pedidos");
    }

  return (
    
    <>
        <PageHeader titulo={"Pedido detalles"} />
        <section id="pedidosdetalle" className='padded'>
            <div className="container">
                <button type="button" className="btn btn-secondary mb-4" onClick={() => redirectPedidosDetalle()}>
                    <i className="bi bi-caret-left-fill"></i> Volver
                </button>
                <div className="row row-cols-xxl-6 row-cols-xl-4 row-cols-lg-3 row-cols-md-2 row-cols-1 g-5">
                    {pedidoSeleccionado.map(item => 
                        <div className="col" key={c++}>
                            <div className="card h-100">
                                <img src={ApiWebURL + item.imagenchica} className="card-img-top" />
                                <div className="card-body">
                                    <h6 className="card-title">{item.nombre} (cod. {item.idproducto})</h6>
                                    <hr />
                                    <table className="table">
                                        <tbody>
                                            <tr>
                                                <td><h6><strong>Pedido</strong></h6></td>
                                                <td className="text-end">{item.idpedido}</td>
                                            </tr>
                                            <tr>
                                                <td><h6><strong>Precio</strong></h6></td>
                                                <td className="text-end">{item.precio}</td>
                                            </tr>
                                            <tr>
                                                <td><h6><strong>Cantidad</strong></h6></td>
                                                <td className="text-end">{item.cantidad}</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <p className="card-text">
                                        <strong>Detalle</strong>
                                    </p>
                                    <p className="card-text">{item.detalle}</p>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </section>
    </>
  )
}

export default PedidosDetalle