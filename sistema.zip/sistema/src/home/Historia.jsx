import "./Historia.css"
function Historia() {
    return (
        <section id="historia" className='padded'>
            <div className="container">
                <h2>Historia</h2>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsa quia explicabo magnam voluptate facilis officia corrupti reiciendis dicta libero quos. Illum dolorum, alias maxime accusamus dolore illo impedit quae ipsam adipisci eum velit ea nihil quas eligendi explicabo error ex repudiandae amet labore. Quam, iure dolores beatae placeat aperiam harum a et dolor ullam possimus veritatis corporis, sit sapiente suscipit quos ipsam reiciendis vero, nulla est quibusdam voluptatibus! Consequatur, voluptas consectetur. Veritatis rerum assumenda tempore repellat maxime voluptate praesentium quae laborum? Sapiente vitae voluptates officia eveniet illo recusandae fugit, cupiditate atque animi praesentium reprehenderit optio eaque blanditiis incidunt ea facilis modi esse dignissimos similique repudiandae autem veniam sit aliquam. Earum et aut, obcaecati amet voluptatem quam placeat fugiat officia omnis!</p>
                <p>Velit delectus atque praesentium unde dignissimos officiis non? Impedit quisquam voluptate ipsa hic fuga quae, velit, obcaecati molestiae provident eaque corrupti necessitatibus, nesciunt nobis maiores ipsum ratione at veniam error voluptatem explicabo fugiat ullam et! Tenetur aspernatur quod ea, quo maiores mollitia repellat ab non ullam odio architecto placeat cum ipsa, laudantium deleniti sapiente quaerat quibusdam. Sit, neque. Obcaecati itaque similique ipsum adipisci qui aliquid placeat, recusandae eaque earum inventore ea. Dolore repellendus a adipisci voluptatibus ducimus magnam, expedita soluta quae molestias ipsum, debitis deserunt repudiandae vitae nesciunt explicabo dolores sapiente suscipit cupiditate ipsam modi rerum! Aliquam, sapiente doloremque quibusdam earum quidem fuga, accusantium sit quae fugiat, labore sunt ab voluptatem similique laborum quisquam maxime architecto quaerat hic accusamus! Cupiditate.</p>
            </div>
        </section>
    )
}

export default Historia