import "./Nosotros.css"
function Nosotros() {
    return (
        <section id="nosotros" className='padded'>
            <div className="container">
                <h2>Nosotros</h2>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusamus blanditiis quaerat commodi. Veritatis, dolor nostrum! Consequuntur libero esse distinctio dolorem rerum iure tenetur aspernatur, impedit quia, ipsam modi, vitae commodi. Rerum adipisci debitis quam eaque beatae ratione saepe similique quos iste? Nulla molestias nemo ea rerum repudiandae temporibus illo corrupti. Doloremque quibusdam, ex laudantium accusantium adipisci impedit quisquam quam libero dolor ipsa ipsum iusto, repudiandae, nam unde laborum aut eius! Est, obcaecati voluptate, minima dicta repellat corrupti delectus exercitationem, a facilis aliquam commodi quaerat laudantium qui esse quis eum enim laborum molestias. Esse, ullam labore sed, molestias error totam minus, sint odit officia maxime necessitatibus repudiandae accusamus? Consectetur ducimus magnam animi atque quam aliquid voluptate alias maiores esse natus, nemo minima, illo id. Quisquam officiis dignissimos ad voluptates, quam, excepturi exercitationem maiores consequuntur, cum obcaecati ab amet quae ipsam? Itaque repellendus perspiciatis, laboriosam quidem maiores sapiente accusamus eius explicabo temporibus provident repudiandae quae voluptatem similique excepturi cupiditate, vitae voluptatum debitis. Temporibus laborum repellendus cum sunt ratione optio nisi debitis in nostrum! Temporibus neque ea repellat eveniet quidem nesciunt, necessitatibus incidunt!</p>
            </div>
        </section>
    )
}

export default Nosotros